package org.example.class1;

public class A1 {


    public static void main(String[] args) {

        String firstName="John";
        String lastName="Adam";
        int dobDay=28;
        String dobMonth="Aug";
        int dobYear=2024;
        String gender="male";
        String phone="+1(928)785-4586";


    }
}
