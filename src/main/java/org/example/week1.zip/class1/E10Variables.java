package org.example.class1;

public class E10Variables {
    public static void main(String[] args) {

        int num1=11;
        int num2=4;
        System.out.println(num1/num2);
        System.out.println(num1%num2);

        double num3=11;
        double num4=4;
        System.out.println(num3/num4);


    }
}
