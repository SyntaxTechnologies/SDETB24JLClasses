package org.example.class1;

public class E1HelloWorld {


    public static void main(String[] args) {

        // This instruction is going to print Hello java on the console
        System.out.println("Hello Java");



        /*
        * These are called multiline comments
        * they are used when we have to write
        * longer comments which can span multiple lines
        * */

        System.out.println("Hello Intellij");
    }


}
