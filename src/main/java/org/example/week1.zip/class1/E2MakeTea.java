package org.example.class1;

public class E2MakeTea {
    public static void main(String[] args) {

        String milk="200ml";
        String water="20ml";
        String tea="small spoon";

        System.out.println(milk);

    }
}
