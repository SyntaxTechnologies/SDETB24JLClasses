package org.example.class1;

public class E3Variables {

    public static void main(String[] args) {

      int age=25;
      int salary=100000;
      String name="John";
      boolean isHungry=false;


    }
}
