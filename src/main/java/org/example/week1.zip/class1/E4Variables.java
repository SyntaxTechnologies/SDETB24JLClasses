package org.example.class1;

public class E4Variables {
    public static void main(String[] args) {

        byte smallestBox=100;
        short mediumBox=10000;
        int largeBox=1000000;
        long verLargeBox=1555555555555L;

        System.out.println(smallestBox);

    }
}
