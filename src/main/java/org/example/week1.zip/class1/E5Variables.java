package org.example.class1;

public class E5Variables {
    public static void main(String[] args) {

       float price=100.5F;
       // double is the most widely used datatype to store floating point numbers
       double weight=5.5;
    }

}
