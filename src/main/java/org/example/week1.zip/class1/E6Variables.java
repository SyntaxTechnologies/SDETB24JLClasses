package org.example.class1;

public class E6Variables {
    public static void main(String[] args) {

        char gender = 'F';
        char symbol = '$';


        boolean isRaining = true;



    }
}
