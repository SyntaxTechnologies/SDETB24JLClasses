package org.example.class1;

public class E7NamingCon {

    public static void main(String[] args) {


        int myAge = 25;
        boolean isUserLogged = true;
        String myName="Adam";
        double yourAge=10.5;

    }
}
