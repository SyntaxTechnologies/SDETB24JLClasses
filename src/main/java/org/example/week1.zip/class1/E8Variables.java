package org.example.class1;

public class E8Variables {
    public static void main(String[] args) {

        int age = 50;
        // updating the value of age variable
         age = 51;
        System.out.println(age);
    }
}
